@foreach($data as $members)
    @inject('job','App\Job')
<tr>
    <td>
        <label class="checkbox checkbox-single">
            <input type="checkbox" value="{{$members->id}}" class="checkable" name="sendMain[]"/>
            <span></span>
        </label>
    </td>
    <td> {{$members->name }} <br> @if($job->find($members->id)) {{$job->find($members->id)->name}}  @else تم حذف الوظيفة @endif</td>
    <td>
        <label class="checkbox checkbox-single">
            <input type="checkbox" value="{{$members->id}}" class="checkable" name="sendSub[]"/>
            <span></span>
        </label>
    </td>
</tr>
@endforeach
