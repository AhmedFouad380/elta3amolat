@if(Request::segment(1) == 'ar' )
<link href="{{asset('dashboard/assets/css/pages/wizard/wizard-6.rtl.css')}}" rel="stylesheet" type="text/css" />
@else
<link href="{{asset('dashboard/assets/css/pages/wizard/wizard-6.css')}}" rel="stylesheet" type="text/css" />
@endif

<div class="wizard wizard-6 d-flex flex-column flex-lg-row flex-column-fluid" id="kt_wizard">
    <!--begin::Container-->
    <div class="wizard-content d-flex flex-column mx-auto py-10 py-lg-20 w-100 w-md-700px">
      <div class="kt-container  kt-container--fluid  kt-grid__item kt-grid__item--fluid">
        <div class="d-flex flex-column-auto flex-column px-10">
            <!--begin: Wizard Nav-->
            <div class="wizard-nav pb-lg-10 pb-3 d-flex flex-column align-items-center align-items-md-start">
                <!--begin::Wizard Steps-->
                <div class="wizard-steps d-flex flex-column flex-md-row">
                    <!--begin::Wizard Step 1 Nav-->
                    <div class="wizard-step flex-grow-1 flex-basis-0" data-wizard-type="step" data-wizard-state="current">
                        <div class="wizard-wrapper pr-lg-7 pr-5">
                            <div class="wizard-icon">
                                <i class="wizard-check ki ki-check"></i>
                                <span class="wizard-number">1</span>
                            </div>
                            <div class="wizard-label mr-3">
                                <h3 class="wizard-title">البيانات الشخصية</h3>
                            </div>
                            <span class="svg-icon svg-icon-success svg-icon-2x"><!--begin::Svg Icon | path:C:\wamp64\www\keenthemes\themes\metronic\theme\html\demo1\dist/../src/media/svg/icons\Navigation\Angle-left.svg--><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
                                <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                    <polygon points="0 0 24 0 24 24 0 24"/>
                                    <path d="M6.70710678,15.7071068 C6.31658249,16.0976311 5.68341751,16.0976311 5.29289322,15.7071068 C4.90236893,15.3165825 4.90236893,14.6834175 5.29289322,14.2928932 L11.2928932,8.29289322 C11.6714722,7.91431428 12.2810586,7.90106866 12.6757246,8.26284586 L18.6757246,13.7628459 C19.0828436,14.1360383 19.1103465,14.7686056 18.7371541,15.1757246 C18.3639617,15.5828436 17.7313944,15.6103465 17.3242754,15.2371541 L12.0300757,10.3841378 L6.70710678,15.7071068 Z" fill="#000000" fill-rule="nonzero" transform="translate(12.000003, 11.999999) scale(-1, 1) rotate(-270.000000) translate(-12.000003, -11.999999) "/>
                                </g>
                            </svg><!--end::Svg Icon--></span>
                        </div>
                    </div>
                    <!--end::Wizard Step 1 Nav-->
                    <!--begin::Wizard Step 2 Nav-->
                    <div class="wizard-step flex-grow-1 flex-basis-0" data-wizard-type="step">
                        <div class="wizard-wrapper pr-lg-7 pr-5">
                            <div class="wizard-icon">
                                <i class="wizard-check ki ki-check"></i>
                                <span class="wizard-number">2</span>
                            </div>
                            <div class="wizard-label mr-3">
                                <h3 class="wizard-title">البيانات الوظيفية</h3>
                            </div>
                            <span class="svg-icon svg-icon-success svg-icon-2x"><!--begin::Svg Icon | path:C:\wamp64\www\keenthemes\themes\metronic\theme\html\demo1\dist/../src/media/svg/icons\Navigation\Angle-left.svg--><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
                                <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                    <polygon points="0 0 24 0 24 24 0 24"/>
                                    <path d="M6.70710678,15.7071068 C6.31658249,16.0976311 5.68341751,16.0976311 5.29289322,15.7071068 C4.90236893,15.3165825 4.90236893,14.6834175 5.29289322,14.2928932 L11.2928932,8.29289322 C11.6714722,7.91431428 12.2810586,7.90106866 12.6757246,8.26284586 L18.6757246,13.7628459 C19.0828436,14.1360383 19.1103465,14.7686056 18.7371541,15.1757246 C18.3639617,15.5828436 17.7313944,15.6103465 17.3242754,15.2371541 L12.0300757,10.3841378 L6.70710678,15.7071068 Z" fill="#000000" fill-rule="nonzero" transform="translate(12.000003, 11.999999) scale(-1, 1) rotate(-270.000000) translate(-12.000003, -11.999999) "/>
                                </g>
                            </svg><!--end::Svg Icon--></span>
                        </div>
                    </div>
                    <!--end::Wizard Step 2 Nav-->
                    <!--begin::Wizard Step 3 Nav-->
                    <div class="wizard-step flex-grow-1 flex-basis-0" data-wizard-type="step">
                        <div class="wizard-wrapper">
                            <div class="wizard-icon">
                                <i class="wizard-check ki ki-check"></i>
                                <span class="wizard-number">3</span>
                            </div>
                            <div class="wizard-label">
                                <h3 class="wizard-title"> بيانات قرار التعين</h3>
                            </div>
                        </div>
                    </div>
                    <!--end::Wizard Step 3 Nav-->
                </div>
                <!--end::Wizard Steps-->
            </div>
            <!--end: Wizard Nav-->
        </div>

        <form class="px-10" novalidate="novalidate" id="kt_form"  method="post" action="/Store_User" enctype="multipart/form-data">
            <!--begin: Wizard Step 1-->
            <div class="pb-5" data-wizard-type="step-content" data-wizard-state="current">
                <!--begin::Title-->

                <div class="form-group row">
                    <div class="col-lg-9 col-xl-6">
                      <div class="image-input image-input-empty image-input-outline" id="kt_image_1" style="background-image: url({{asset('dashboard/assets/media/users/blank.png')}})">
                        <div class="image-input-wrapper"></div>
                        <label class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="change" data-toggle="tooltip" title="" data-original-title="Change avatar">
                          <i class="fa fa-pen icon-sm text-muted"></i>
                          <input type="file" name="img" accept=".png, .jpg, .jpeg" required />
                          <input type="hidden" name="logo_remove" />
                        </label>
                        <span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="cancel" data-toggle="tooltip" title="Cancel avatar">
                          <i class="ki ki-bold-close icon-xs text-muted"></i>
                        </span>
                        <span class="btn btn-xs btn-icon btn-circle btn-white btn-hover-text-primary btn-shadow" data-action="remove" data-toggle="tooltip" title="Remove avatar">
                          <i class="ki ki-bold-close icon-xs text-muted"></i>
                        </span>
                      </div>
                    </div>
                  </div>

                <div class="form-group">
                    <label>اسم الموظف </label>
                    <input type="text" class="form-control form-control-solid" name="name" required placeholder="الاسم بالكامل" >
                </div>
                <div class="form-group">
                    <label>الاسم باللغة الانجليزية </label>
                    <input type="text" class="form-control form-control-solid" name="en_name" required placeholder="الاسم بالكامل" >
                </div>
                <div class="form-group">
                    <label>رقم الهوية </label>
                    <input type="number" class="form-control form-control-solid" name="national_id" required placeholder="رقم الهوية" >
                </div>
                <div class="form-group">
                    <label>تاريخ انتهاء رقم الهوية </label>
                    <input type="date" class="form-control " name="date_national_id" required value="">
                </div>
                <div class="form-group">
                    <label>رقم الجواز </label>
                    <input type="number" class="form-control form-control-solid" name="passport_id" required placeholder="رقم الجواز" >
                </div>
                <div class="form-group">
                    <label>تاريخ انتهاء رقم الجواز </label>
                    <input type="date" class="form-control" name="date_passport_id" required value="">
                </div>
                <div class="form-group">
                    <label>الجنسية  </label>
                    @inject('Nationality','App\Nationality')
                    <select name="country_id" class="form-control form-control-lg"  id="kt_select2_1">
                        @foreach($Nationality->all() as $data)
                            <option value="{{$data->id}}">{{$data->name}}</option>
                        @endforeach
                    </select>
                </div>
                <div class="form-group">
                    <label>رقم التحويلة  </label>
                    <input type="number" class="form-control form-control-solid" name="converted_num" required placeholder="رقم الجواز" >
                </div>
                <div class="row">
                    <div class="col-xl-6">
                        <div class="form-group">
                            <label>رقم الجوال </label>
                            <input type="tel" class="form-control form-control-solid" required name="phone" placeholder="phone" >
                        </div>
                    </div>
                    <div class="col-xl-6">
                        <div class="form-group">
                            <label>البريد الالكتروني </label>
                            <input type="email" class="form-control form-control-solid" required name="email" placeholder="Email" >
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label>تاريخ الميلاد </label>
                    <input type="date" class="form-control" name="birth_date" required value="">
                </div>
                <div class="form-group">
                    <label>العنوان  </label> 
                    <input type="text" class="form-control form-control-solid" name="address" required value="">
                </div>

                    <div class="form-group">
                        <label>النوع :</label>
                        <div class="radio-inline">
                            <label class="radio">
                            <input type="radio" name="type" value="1" />
                            <span></span>ذكر</label>
                            <label class="radio">
                            <input type="radio" name="type"  value="2" />
                            <span></span>انثى</label>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>الديانة :</label>
                        <div class="radio-inline">
                            <label class="radio">
                            <input type="radio" name="religion" value="1" />
                            <span></span>مسلم</label>
                            <label class="radio">
                            <input type="radio" name="religion"  value="2" />
                            <span></span>غير مسلم</label>
                        </div>
                    </div>

                <div class="form-group">
                    <label>الحالة الاجتماعية   </label>
                    <select name="relationship" class="form-control form-control-lg"  id="kt_select2_1">
                        <option value="1">اعزب</option>
                        <option value="2">متزوج </option>
                    </select>
                </div>
                <!--end::Form Group-->
            </div>
            <!--end: Wizard Step 1-->
            <!--begin: Wizard Step 2-->
            <div class="pb-5" data-wizard-type="step-content">
                <!--begin::Title-->
                <div class="form-group">
                    <label>الرقم الوظيفي </label>
                    <input type="number" class="form-control form-control-solid" name="job_num" placeholder="الرقم الوظيفي" value="">
                </div>
                <div class="form-group">
                    <label>تاريخ التعيين</label>
                    <input type="date" class="form-control" name="start_job_date" placeholder="تاريخ التعيين" >
                </div>
                <div class="form-group">
                    <label> الوظيفة الاساسية   </label>
                    @inject('Job','App\Job')
                    <select name="mainJob_id" class="form-control form-control-lg"  id="kt_select2_1">
                        @foreach($Job->all() as $data)
                            <option value="{{$data->id}}">{{$data->name}}</option>
                        @endforeach
                    </select>
                </div>
                <div class="form-group">
                    <label> وظيفة التكليف   </label>
                    @inject('Job','App\Job')
                    <select name="subJob_id" class="form-control form-control-lg"  id="kt_select2_1">
                        @foreach($Job->all() as $data)
                            <option value="{{$data->id}}">{{$data->name}}</option>
                        @endforeach
                    </select>
                </div>
                <div class="form-group">
                    <label>  قسم / ادارة    </label>
                    <input type="text" class="form-control form-control-solid" name="management" placeholder="قسم / ادارة" >
                </div>

                <div class="form-group">
                    <label>  اسم البنك     </label>
                    @inject('Bank','App\Bank')
                    <select name="bank_id" class="form-control form-control-lg"  id="kt_select2_1">
                        @foreach($Bank->all() as $data)
                            <option value="{{$data->id}}">{{$data->name}}</option>
                        @endforeach
                    </select>
                </div>
                <div class="form-group">
                    <label>رقم حساب (اي بان) </label>
                    <input type="number" class="form-control form-control-solid" name="ipan" placeholder="رقم حساب (اي بان)" >
                </div>
                <div class="form-group">
                    <label>المستوى الوظيفي  </label>
                    <input type="number" class="form-control form-control-solid" name="jobLevel" placeholder="المستوى الوظيفي" >
                </div>
                <div class="form-group">
                    <label>الدرجة الوظيفية  </label>
                    <input type="number" class="form-control form-control-solid" name="jobPercent" placeholder="الدرجة الوظيفية" >
                </div>
                <div class="form-group">
                    <label>درجة البدالات المميزة   </label>
                    <input type="number" class="form-control form-control-solid" name="badalat" placeholder="درجة البدالات المميزة" >
                </div>
                <div class="form-group">
                    <label>  مقر العمل    </label>
                    @inject('Category','App\Category')
                    <select name="category_id" class="form-control form-control-lg"  id="kt_select2_1">
                        @foreach($Category->all() as $data)
                            <option value="{{$data->id}}">{{$data->name}}</option>
                        @endforeach
                    </select>
                </div>
                <div class="form-group">
                    <label>  التامينات    </label>
                    @inject('Category','App\Category')
                    <select name="insurance_id" class="form-control form-control-lg"  id="kt_select2_1">
                        @foreach($Category->all() as $data)
                            <option value="{{$data->id}}">{{$data->name}}</option>
                        @endforeach
                    </select>
                </div>
                <div class="form-group">
                    <label>نسبة الشركة من التامينات   </label>
                    <input type="number" class="form-control form-control-solid" name="comp_insurance_percent" placeholder="نسبة الشركة من التامينات" >
                </div>
                <div class="form-group">
                    <label>نسبة الموظف من التامينات   </label>
                    <input type="number" class="form-control form-control-solid" name="emp_insurance_percent" placeholder="نسبة الموظف من التامينات" >
                </div>
                <!--end::Row-->
            </div>
            <!--end: Wizard Step 2-->
            <!--begin: Wizard Step 3-->
            <div class="pb-5" data-wizard-type="step-content">
                <!--begin::Title-->
                <div class="form-group">
                    <label>رقم العقد  </label>
                    <input type="number" class="form-control form-control-solid" name="contract_num" required placeholder="رقم العقد" value="">
                    <span class="form-text text-muted">Please enter your phone number.</span>
                </div>
                <div class="form-group">
                    <label>تاريخ القرار</label>
                    <input type="date" class="form-control" required name="start_contract_date" placeholder="تاريخ التعيين" >
                </div>
                <div class="form-group">
                    <label>جهة القرار   </label>
                    <input type="text" class="form-control form-control-solid" name="decision_point" required placeholder="رقم العقد" value="">
                </div>
                <div class="form-group">
                    <label>تاريخ انتهاء العقد </label>
                    <input type="date" class="form-control" required name="end_contract_date" placeholder="تاريخ التعيين" >
                </div>
            </div>
            <!--end: Wizard Step 3-->
            <!--begin: Wizard Actions-->
            <div class="d-flex justify-content-between pt-7">
                <div class="mr-2">
                    <button type="button" class="btn btn-light-primary font-weight-bolder font-size-h6 pr-8 pl-6 py-4 my-3 mr-3" data-wizard-type="action-prev">
                        <span class="svg-icon svg-icon-md ml-2">
                            <!--begin::Svg Icon | path:assets/media/svg/icons/Navigation/Right-2.svg-->
                            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
                                <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                    <polygon points="0 0 24 0 24 24 0 24" />
                                    <rect fill="#000000" opacity="0.3" transform="translate(8.500000, 12.000000) rotate(-90.000000) translate(-8.500000, -12.000000)" x="7.5" y="7.5" width="2" height="9" rx="1" />
                                    <path d="M9.70710318,15.7071045 C9.31657888,16.0976288 8.68341391,16.0976288 8.29288961,15.7071045 C7.90236532,15.3165802 7.90236532,14.6834152 8.29288961,14.2928909 L14.2928896,8.29289093 C14.6714686,7.914312 15.281055,7.90106637 15.675721,8.26284357 L21.675721,13.7628436 C22.08284,14.136036 22.1103429,14.7686034 21.7371505,15.1757223 C21.3639581,15.5828413 20.7313908,15.6103443 20.3242718,15.2371519 L15.0300721,10.3841355 L9.70710318,15.7071045 Z" fill="#000000" fill-rule="nonzero" transform="translate(14.999999, 11.999997) scale(1, -1) rotate(90.000000) translate(-14.999999, -11.999997)" />
                                </g>
                            </svg>
                            <!--end::Svg Icon-->
                        </span>
                        السابق</button>
                </div>
                <div>
                    <button type="submit" form="kt_form" onclick="document.getElementById('kt_form').submit();" class="btn btn-primary font-weight-bolder font-size-h6 pl-8 pr-4 py-4 my-3" data-wizard-type="action-submit">حفظ</button>
                    <button type="button" class="btn btn-primary font-weight-bolder font-size-h6 pl-8 pr-4 py-4 my-3" data-wizard-type="action-next">التالي
                        <span class="svg-icon svg-icon-md mr-2">
                            <!--begin::Svg Icon | path:assets/media/svg/icons/Navigation/Left-2.svg-->
                            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="24px" height="24px" viewBox="0 0 24 24" version="1.1">
                                <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                                    <polygon points="0 0 24 0 24 24 0 24" />
                                    <rect fill="#000000" opacity="0.3" transform="translate(15.000000, 12.000000) scale(-1, 1) rotate(-90.000000) translate(-15.000000, -12.000000)" x="14" y="7" width="2" height="10" rx="1" />
                                    <path d="M3.7071045,15.7071045 C3.3165802,16.0976288 2.68341522,16.0976288 2.29289093,15.7071045 C1.90236664,15.3165802 1.90236664,14.6834152 2.29289093,14.2928909 L8.29289093,8.29289093 C8.67146987,7.914312 9.28105631,7.90106637 9.67572234,8.26284357 L15.6757223,13.7628436 C16.0828413,14.136036 16.1103443,14.7686034 15.7371519,15.1757223 C15.3639594,15.5828413 14.7313921,15.6103443 14.3242731,15.2371519 L9.03007346,10.3841355 L3.7071045,15.7071045 Z" fill="#000000" fill-rule="nonzero" transform="translate(9.000001, 11.999997) scale(-1, -1) rotate(90.000000) translate(-9.000001, -11.999997)" />
                                </g>
                            </svg>
                            <!--end::Svg Icon-->
                        </span></button>
                </div>
            </div>
            <!--end: Wizard Actions-->
        </form>
    </div>
    <!--end::Container-->
</div>


<script src="{{asset('dashboard/assets/js/pages/custom/wizard/wizard-6.js')}}"></script>