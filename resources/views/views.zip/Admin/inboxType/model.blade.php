

<form method="post" action="/Update_inboxType">
    @csrf
    <div class="col-xl-12">
        <div class="kt-section__body">

            <div class="form-group row">
                <label class="col-xl-3 col-lg-3 col-form-label">@if(Request::segment(1) == 'ar') الاسم   @else  arabic Name @endif</label>
                <div class="col-lg-9 col-xl-9">
                    <input class="form-control" type="text" name="ar_name" value="{{$data->ar_name}}">
                    <input class="form-control" type="hidden" name="id" value="{{$data->id}}">
                </div>
            </div>
            <div class="form-group row">
                <label class="col-xl-3 col-lg-3 col-form-label">@if(Request::segment(1) == 'ar') الاسم باللغة الانجليزية   @else  english Name @endif</label>
                <div class="col-lg-9 col-xl-9">
                    <input class="form-control" type="text" name="en_name" value="{{$data->en_name}}">
                </div>

            <div class="form-group row">
                <label class="col-xl-3 col-lg-3 col-form-label">@if(Request::segment(1) == 'ar') للمدير فقط   @else  Name @endif</label>
                <div class="col-lg-9 col-xl-9">
                    <input class="form-control" type="checkbox" @if($data->role == 1) checked @endif name="role" value="1" >
                </div>
            </div>
            <div class="form-group row">
                <label class="col-xl-3 col-lg-3 col-form-label">@if(Request::segment(1) == 'ar') نوع الاحالة   @else  Name @endif</label>
                <div class="col-lg-9 col-xl-9">
                    <select class="form-control" name="type">
                        @if($data->type == 1)
                            <option selected value="1"> للحفظ </option>
                            <option value="2"> للتصدير  </option>
                            <option value="3"> غير ذلك  </option>
                        @elseif($data->type == 2 )
                            <option value="1"> للحفظ </option>
                            <option selected value="2"> للتصدير  </option>
                            <option value="3"> غير ذلك  </option>
                        @elseif($data->type == 2 )
                            <option value="1"> للحفظ </option>
                            <option value="2"> للتصدير  </option>
                            <option  selected value="3"> غير ذلك  </option>
                        @endif

                    </select>
                </div>
            </div>
        </div>
    </div>
    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">اللغاء</button>
        <button type="submit" class="btn btn-primary">حفظ</button>
    </div>
</form>






